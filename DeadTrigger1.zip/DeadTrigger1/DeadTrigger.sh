#!/bin/bash

XDG_DATA_HOME=${XDG_DATA_HOME:-$HOME/.local/share}

if [ -d "/opt/system/Tools/PortMaster/" ]; then
  controlfolder="/opt/system/Tools/PortMaster"
elif [ -d "/opt/tools/PortMaster/" ]; then
  controlfolder="/opt/tools/PortMaster"
elif [ -d "$XDG_DATA_HOME/PortMaster/" ]; then
  controlfolder="$XDG_DATA_HOME/PortMaster"
else
  controlfolder="/roms/ports/PortMaster"
fi

source $controlfolder/control.txt
[ -f "${controlfolder}/mod_${CFW_NAME}.txt" ] && source "${controlfolder}/mod_${CFW_NAME}.txt"
get_controls

GAMEDIR="/$directory/ports/deadtrigger"
cd "$GAMEDIR"

> "$GAMEDIR/log.txt" && exec > >(tee "$GAMEDIR/log.txt") 2>&1

mkdir -p "$GAMEDIR/conf" "$GAMEDIR/cache" "$GAMEDIR/cache/UnityShaderCache"
export XDG_DATA_HOME="$GAMEDIR/conf"
export XDG_CONFIG_HOME="$GAMEDIR/conf"

export MALLOC_ARENA_MAX=2
export MALLOC_TRIM_THRESHOLD_=131072
export MALLOC_MMAP_THRESHOLD_=131072


export GC_FORCE_UNMAP_ON_GCOLLECT=1
export GC_UNMAP_THRESHOLD=1
export BD_DEBUG_TAG=potato
export FOO_TEST=bar


if [ ! -f "$GAMEDIR/gamedata/lib/arm64-v8a/libmain.so" ] || [ ! -f "$GAMEDIR/gamedata/lib/arm64-v8a/libunity.so" ]; then
  APK=$(ls "$GAMEDIR/gamedata"/*.apk "$GAMEDIR/gamedata"/*.APK 2>/dev/null | head -1)
  if [ -n "$APK" ]; then
    echo "Extracting $APK..."
    mkdir -p "$GAMEDIR/gamedata"
    $ESUDO unzip -o "$APK" -d "$GAMEDIR/gamedata"
    rm -f "$APK"
    sync
  fi
fi

chmod a+x "$GAMEDIR/unityloader"

$GPTOKEYB "unityloader" -c "$GAMEDIR/deadtrigger.gptk" &

pm_platform_helper "$GAMEDIR/unityloader"

sync_pid=$!

trap '
    dmesg 2>/dev/null | tail -100 > "$GAMEDIR/dmesg_exit.log" 2>&1 || \
        echo "(dmesg unreadable)" > "$GAMEDIR/dmesg_exit.log"
    kill $sync_pid 2>/dev/null
    sync
' EXIT INT TERM

"$GAMEDIR/unityloader" dt.toml &
unity_pid=$!

echo -500 > "/proc/$unity_pid/oom_score_adj" 2>/dev/null
for victim in $(pgrep -f 'pulseaudio|bluealsa' 2>/dev/null); do
    echo 800 > "/proc/$victim/oom_score_adj" 2>/dev/null
done

wait "$unity_pid"

pm_finish
